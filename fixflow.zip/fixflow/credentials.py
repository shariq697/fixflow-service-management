DB_HOST = "52.90.36.247"
DB_USER = "fixuser"
DB_PWD = "password123"
DB_NAME = "fixflow"
